
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class BusReservationSystem {
    private static List<Ticket> availableTickets;

    public static void main(String[] args) {
        availableTickets = new ArrayList<>();
        for(int i=0;i<10;i++){
         availableTickets.add(new Ticket("A"+i, "Not BOOKED YET"));
        }

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter your role (admin/customer): ");
        String role = scanner.nextLine();

        if (role.equalsIgnoreCase("admin")) {
            handleAdmin(scanner);
        } else if (role.equalsIgnoreCase("customer")) {
            handleCustomer(scanner);
        }
    }

    private static void handleAdmin(Scanner scanner) {
        System.out.print("Enter username: ");
        String username = scanner.nextLine();

        System.out.print("Enter password: ");
        String password = scanner.nextLine();

        if (authenticateAdmin(username, password)) {
            int d=1;
             System.out.println("--------Admin login successful--------");
           while(d==1){
            System.out.println("1. View Available Tickets");
            System.out.println("2. View Booked Tickets");
            System.out.println("3. Book a new Ticket");
             System.out.println("4. EXIT");
       
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
           
            switch (choice) {
                case 1:
                    viewAvailableTickets();
                    break;
                case 3:
                    viewAvailableTickets();
                    scanner.nextLine(); // Consume the newline character
                    System.out.print("Enter ticket number: ");
                    String ticketNumber = scanner.nextLine();

                    System.out.print("Enter passenger name: ");
                    String passengerName = scanner.nextLine();

                    bookTicket(ticketNumber, passengerName);
                    break;
                 case 2:
                   viewBookedBTickets();
                    break;
                case 4:
                    d=0;
                    break;
                default:
                    System.out.println("Invalid choice.");
                    break;
            }
            }
        } else {
            System.out.println("Invalid username or password.");
        }
    }

    private static void handleCustomer(Scanner scanner) {
         int d=1;
           while(d==1){
        System.out.println("Welcome, customer!");
        System.out.println("1. View Available Tickets");
        System.out.println("2. Book Ticket");

        System.out.print("Enter your choice: ");
        int choice = scanner.nextInt();

        switch (choice) {
            case 1:
                viewAvailableTickets();
                break;
            case 2:
                scanner.nextLine(); // Consume the newline character
                viewAvailableTickets();
                System.out.print("Enter ticket number: ");
                String ticketNumber = scanner.nextLine();

                System.out.print("Enter passenger name: ");
                String passengerName = scanner.nextLine();
                
                bookTicket(ticketNumber, passengerName);
                break;
                 case 3:
                    d=0;
                    break;
            default:
                System.out.println("Invalid choice.");
                break;
        }
           }
    }

    private static boolean authenticateAdmin(String username, String password) {
        // Add your authentication logic here
        String adminUsername = "admin";
        String adminPassword = "password";

        return adminUsername.equals(username) && adminPassword.equals(password);
    }

    private static void viewAvailableTickets() {
        int count=0;
        System.out.println("---------Available Tickets---------");
        for (Ticket ticket : availableTickets) {
        if(ticket.getPassengerName()=="Not BOOKED YET"){
                System.out.println(ticket);
                count++;
        }
        }
        if(count==0){
            System.out.println("Sorry No available tickets");
        }
    }
    private static void viewBookedBTickets() {
        int count=0;
        System.out.println("---------Booked  Tickets---------");
        for (Ticket ticket : availableTickets) {
        if(ticket.getPassengerName()!="Not BOOKED YET"){
                System.out.println(ticket);
        }
        }
        if(count==0){
            System.out.println("Sorry No available tickets");
        }
    }

   private static void bookTicket(String ticketId, String passengerName) {
for (Ticket ticket : availableTickets) {
    if (ticket.getTicketNumber().trim().equals(ticketId)) {
    ticket.setPassengerName(passengerName);
    System.out.println("Ticket Booked successfully.");
return;
}
}
System.out.println("Ticket not found/Invalid Ticked entered Please choose from tickets avialble.");
}
}

class Ticket {
    private String ticketNumber;
    private String passengerName;

    
    public Ticket(String ticketNumber, String passengerName) {
        this.ticketNumber = ticketNumber;
        this.passengerName = passengerName;
    }

    @Override
       public String toString() {
        return "Ticket Number: " + ticketNumber + ", Passenger Name: " + passengerName;
    }

    public String getPassengerName() {
        return passengerName;
    }

    public String getTicketNumber() {
        return ticketNumber;
    }

    public void setPassengerName(String passengerName) {
        this.passengerName = passengerName;
    }
       
}
